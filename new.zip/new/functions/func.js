const sleep = ms => new Promise(r => setTimeout(r, ms));
const fs = require('fs');
const path = require('path');

const HOST = 'aemine.vn';
const PORT = 25565;
const VERSION = '1.12.2';
const REJOIN_DELAY = 3600000; 

function getOreAccounts() {
    const accountsPath = path.join(__dirname, '..', 'data', 'accounts.json');
    try {
        const data = fs.readFileSync(accountsPath, 'utf8');
        const json = JSON.parse(data);
        if (json.ore && Array.isArray(json.ore.accounts)) {
            return json.ore.accounts;
        } else {
            console.error('Error: JSON structure invalid. Expected json.ore.accounts array.');
            return [];
        }
    } catch (error) {
        console.error(`Error reading or parsing accounts file at ${accountsPath}: ${error.message}`);
        return [];
    }
}


function getMobsAccounts() {
    const accountsPath = path.join(__dirname, '..', 'data', 'accounts.json');
    try {
        const data = fs.readFileSync(accountsPath, 'utf8');
        const json = JSON.parse(data);
        if (json.mob && Array.isArray(json.mob.accounts)) {
            return json.mob.accounts;
        } else {
            console.error('Error: JSON structure invalid. Expected json.mob.accounts array.');
            return [];
        }
    } catch (error) {
        console.error(`Error reading or parsing accounts file at ${accountsPath}: ${error.message}`);
        return [];
    }
}

function setupConsoleFilter() {
    const origWarn = console.warn;
    const origErr = console.error;

    function filterConsole(origFn, ...a) {
        if (a.join(" ").includes("Ignoring block entities as chunk failed to load")) return;
        origFn(...a);
    }

    console.warn = (...a) => filterConsole(origWarn, ...a);
    console.error = (...a) => filterConsole(origErr, ...a);
}

async function join(bot) {
    await sleep(2000);
    bot.setQuickBarSlot(4);
    bot.activateItem();
}

async function dig(bot, username) {
    await sleep(2000);
    bot.chat('/home');
    console.log(`${username} đang đào`);

    while (true) {
        const block = bot.blockAtCursor(5);

        if (block) {
            try {
                await bot.dig(block, 'ignore', 'raycast');
                await sleep(600 + Math.random() * 100);
            } catch (err) {
                console.log(`${username} lỗi đào:`, err.message);
                await sleep(3000); 
            }
        } else {
            await sleep(200);
        }
    }
}

async function afk(bot, username) {
    await sleep(2000);
    bot.chat('/home');
    console.log(`${username} đang afk mob`);
    await sleep(2000);
    bot.chat('/sit');
}

module.exports = { 
    sleep,
    getOreAccounts,
    getMobsAccounts, 
    setupConsoleFilter,
    dig,
    join,
    afk,
    HOST,
    PORT,
    VERSION,
    REJOIN_DELAY
};
