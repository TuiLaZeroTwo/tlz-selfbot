const mineflayer = require('mineflayer');
const { 
    sleep, 
    getMobsAccounts, 
    join, 
    afk,
    HOST, 
    PORT, 
    VERSION
} = require('../functions/func'); 

function startBot(username, password) {
    const bot = mineflayer.createBot({
        host: HOST,
        port: PORT,
        auth: 'offline',
        username: username, 
        version: VERSION
    });

    bot.once('spawn', () => { 	
        bot.chat(`/login ${password}`); 
        sleep(2000);
        join(bot);
        sleep(2000);
        console.log(`${username} đã vào hub`);
    });

    bot.on('messagestr', (message) => {
        if (message.includes('Bạn không có thư mới.')) {
            afk(bot, username); 
            return; 
        }
    });

    bot.on('error', (err) => {
        console.error(`[ERROR] Bot ${username} encountered an error: ${err.message}`);
    });

    bot.on('end', (reason) => {
        console.log(`[STATUS] Bot ${username} disconnected. Reason: ${reason}`);
        
        if (reason !== 'disconnect.quitting') {
            console.log(`[RECONNECT] ${username} attempting to restart in 5s...`);
            setTimeout(() => {
                startBot(username, password); 
            }, 5000);
        }
    });

    bot.on('windowOpen', async (window) => {
        await sleep(2000);
        
        if (window.title === '{"text":"§e§lＡｅｍｉｎｅ.ｖｎ§r"}') {
            await bot.clickWindow(20, 0, 0);
            return;
        }
        if (window.title === '{"text":"§8Game Menu ︱ §c§lAE§f§lMINE.VN"}') {
            await bot.clickWindow(15, 0, 0);
            return;
        }
    });
}

async function startMobCluster() {
    const accounts = getMobsAccounts(); 

    if (accounts.length === 0) {
        console.error('No mob accounts loaded. Exiting.');
        process.exit(1);
    }

    console.log(`Starting ${accounts.length} bot(s) with 5-second delay between each...`);
    
    for (const account of accounts) {
        startBot(account.username, account.password);
        
        await sleep(5000); 
    }
}

module.exports = { startMobCluster };
