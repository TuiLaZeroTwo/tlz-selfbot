const { startOreCluster } = require('./modules/ore');
const { startMobCluster } = require('./modules/mob');

const { 
    setupConsoleFilter, 
} = require('./functions/func'); 
setupConsoleFilter(); 


startOreCluster();
startMobCluster();
